In a real site, this file would be part of the Slick library.
